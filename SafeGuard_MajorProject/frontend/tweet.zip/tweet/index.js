require("dotenv").config({ path: __dirname + "/.env" });

// const { download } = require("./utilities");
const { twitterClient } = require("./twitterClient.js");

const tweet = async () => {
  try {
    const mediaId1 = await twitterClient.v1.uploadMedia(
      "../backend/uploads/john-doe-image.jpeg"
    );
    console.log(mediaId1);
    await twitterClient.v2.tweet({
      text: "New Post v1",
      media: {
        media_ids: [mediaId1],
      },
    });
  } catch (e) {
    console.log(e);
  }
};

module.exports = { tweet };
