const { tweet } = require("./index");

console.log("helloo.....");
tweet();
